package com.example.cafeteria_poo;

public class BaseController {
    //Como no hay nada no se le agrega nada.
}
